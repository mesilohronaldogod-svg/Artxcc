# Artx — Android project

В архив включён текущий HTML-клиент Artx целиком: интерфейс, встроенные игровые данные и Canvas-игровой модуль находятся в `www/index.html`. Приложение подключается к уже существующему Supabase-проекту Artx.

## Что уже подготовлено

- Android-оболочка на Capacitor (проект генерируется командой ниже).
- Встроенный клиент Artx и игровой код внутри `www/index.html`.
- Подключение к существующей Supabase-базе.
- Исправленный сценарий Google OAuth для Android: системный браузер + возврат в `com.artx.app://auth/callback`.
- Серверная Edge Function `artx-ai-support`, развёрнутая в Supabase, проверяет JWT и определяет владельца через `artx_admins`.
- История ИИ-чата с RLS: пользователь видит только свои обращения.

## Сборка Android-проекта

Нужны Node.js 20+, Android Studio и Android SDK.

```bash
npm install
npm run android:add
```

Затем добавьте intent-filter из `android-config/intent-filter.xml` внутрь элемента `<activity>` в `android/app/src/main/AndroidManifest.xml`, затем выполните:

```bash
npm run android:sync
npm run android:open
```

В Android Studio выберите Build → Build Bundle(s) / APK(s) → Build APK(s).

## Google OAuth — обязательная настройка

В Supabase Dashboard → Authentication → URL Configuration добавьте в Redirect URLs:

`com.artx.app://auth/callback`

В Google Cloud OAuth Client для веб-клиента должен быть разрешён callback Supabase:

`https://aecbmuzkmndsuiohvxmc.supabase.co/auth/v1/callback`

Проверьте, что Google включён как Provider в Supabase Auth. После сборки протестируйте вход именно в установленном APK.

## Подключение ИИ

ИИ вызывается только серверной Edge Function. Ключ модели не хранится в APK или HTML. В Supabase → Edge Functions → Secrets задайте:

- `ARTX_AI_URL` — endpoint API, совместимый с форматом OpenAI Chat Completions;
- `ARTX_AI_KEY` — новый секретный ключ провайдера;
- `ARTX_AI_MODEL` — точное имя модели.

Функция уже развёрнута как `artx-ai-support` (version 2). Пока эти три секрета не заданы, функция безопасно вернёт `ai_not_configured`, и модель не ответит.

## Как распознаётся владелец

Сервер проверяет наличие текущего Supabase `auth.uid()` в `public.artx_admins`. Владелец уже присутствует в этой таблице. Ник и данные из localStorage не дают административных прав.

ИИ получает профиль текущего пользователя, список игр и, для владельца, агрегированную статистику. Это безопасный контекст для ответов. Произвольный SQL, пароли, ключи и личные переписки других пользователей ИИ не получает. Для реальных административных действий нужны отдельные серверные команды с проверкой `artx_admins`.

## Важно про базу и APK

Общая база Artx остаётся в Supabase — не встраивается как файл SQLite в APK. Так аккаунты, покупки, игры и сообщения остаются общими на всех устройствах и защищаются RLS. Архив содержит клиент игры и серверные файлы, но не содержит копию приватных пользовательских данных.

## Ключи

Ранее присланный в чат API-ключ не вшит в проект. Его следует отозвать/перевыпустить и сохранить новый ключ только в Supabase Secrets.

## Упрощённая сборка через GitHub Actions

В архив добавлен workflow `.github/workflows/build-apk.yml`. Он сам устанавливает Capacitor, генерирует Android-проект, добавляет Google OAuth deep link и собирает APK в облаке GitHub.

1. Создайте на GitHub новый **пустой** репозиторий.
2. Загрузите в него содержимое этой папки (файл `package.json` должен лежать в корне репозитория).
3. Откройте вкладку **Actions** и разрешите запуск workflows, если GitHub попросит.
4. Запустите **Build Artx APK** через кнопку **Run workflow** (или дождитесь сборки после push).
5. Откройте завершённый запуск workflow и скачайте `Artx-debug-apk` в разделе **Artifacts**.

Это debug APK для установки и тестирования. Для Google OAuth всё равно добавьте `com.artx.app://auth/callback` в Supabase → Authentication → URL Configuration → Redirect URLs.
