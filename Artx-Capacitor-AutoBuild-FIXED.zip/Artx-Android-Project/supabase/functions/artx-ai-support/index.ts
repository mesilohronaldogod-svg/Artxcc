import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, x-client-info, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};
const out = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: cors });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return out({ error: "method_not_allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return out({ error: "unauthorized" }, 401);

    const url = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authClient = createClient(url, anonKey, { auth: { persistSession: false } });
    const { data: authData, error: authError } = await authClient.auth.getUser(token);
    if (authError || !authData.user) return out({ error: "unauthorized" }, 401);

    const aiUrl = Deno.env.get("ARTX_AI_URL");
    const aiKey = Deno.env.get("ARTX_AI_KEY");
    const aiModel = Deno.env.get("ARTX_AI_MODEL");
    if (!aiUrl || !aiKey || !aiModel) return out({ error: "ai_not_configured" }, 503);

    const body = await req.json();
    const message = String(body.message || "").trim();
    if (!message || message.length > 4000) return out({ error: "invalid_message" }, 400);
    const threadId = String(body.thread_id || crypto.randomUUID());
    if (!/^[0-9a-f-]{36}$/i.test(threadId)) return out({ error: "invalid_thread" }, 400);

    const db = createClient(url, serviceKey, { auth: { persistSession: false } });
    const userId = authData.user.id;
    const { data: adminRow } = await db.from("artx_admins")
      .select("user_id").eq("user_id", userId).maybeSingle();
    const isOwner = !!adminRow;

    const [{ data: profile }, { data: games }, { data: history }] = await Promise.all([
      db.from("artx_profiles").select("username,email,data").eq("user_id", userId).maybeSingle(),
      db.from("artx_games").select("id,title,owner,local_id,created_at").order("created_at", { ascending: false }).limit(40),
      db.from("artx_support_messages").select("role,content").eq("user_id", userId)
        .eq("thread_id", threadId).order("created_at", { ascending: true }).limit(12),
    ]);

    const appContext: Record<string, unknown> = {
      current_user: {
        id: userId,
        email: authData.user.email || null,
        username: profile?.username || null,
        profile_data: profile?.data || null,
      },
      owner: isOwner,
      visible_games: (games || []).map(g => ({
        id: g.id, title: g.title, creator_id: g.owner, local_id: g.local_id,
      })),
    };

    if (isOwner) {
      const counts = await Promise.all([
        db.from("artx_profiles").select("*", { count: "exact", head: true }),
        db.from("artx_games").select("*", { count: "exact", head: true }),
        db.from("messages").select("*", { count: "exact", head: true }),
        db.from("conversations").select("*", { count: "exact", head: true }),
      ]);
      appContext.owner_dashboard = {
        profiles: counts[0].count ?? null,
        published_games: counts[1].count ?? null,
        messages: counts[2].count ?? null,
        conversations: counts[3].count ?? null,
      };
    }

    const { error: saveError } = await db.from("artx_support_messages").insert({
      user_id: userId, thread_id: threadId, role: "user", content: message,
    });
    if (saveError) return out({ error: "save_failed" }, 500);

    const system = `Ты — встроенный ИИ-помощник Artx. Отвечай на русском языке.
Текущий авторизованный пользователь и разрешённый контекст приложения переданы в JSON ниже.
owner=true означает, что сервер подтвердил владельца по таблице artx_admins, а не по нику или email.
Для владельца помогай с администрированием, диагностикой и устройством проекта.
Для обычного пользователя помогай только с его собственным аккаунтом и общедоступными функциями.
Ты можешь читать только переданный контекст; не утверждай, что менял базу, аккаунты, игры, валюту или настройки.
Не раскрывай приватные данные других пользователей, токены, ключи, пароли, коды входа и служебные секреты.
Не выполняй произвольный SQL и не проси пользователя присылать секреты.
Если нужных данных нет в контексте, честно скажи об этом.

Контекст:
${JSON.stringify(appContext)}`;

    const response = await fetch(aiUrl, {
      method: "POST",
      headers: { "Authorization": `Bearer ${aiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: aiModel,
        messages: [
          { role: "system", content: system },
          ...(history || []).map(m => ({ role: m.role, content: m.content })),
          { role: "user", content: message },
        ],
        temperature: 0.35,
        max_tokens: 900,
      }),
    });
    if (!response.ok) {
      console.error("AI provider error", response.status, (await response.text()).slice(0, 400));
      return out({ error: "provider_error" }, 502);
    }
    const result = await response.json();
    const answer = String(result.choices?.[0]?.message?.content || result.output_text || "").trim();
    if (!answer) return out({ error: "empty_answer" }, 502);

    const { error: replyError } = await db.from("artx_support_messages").insert({
      user_id: userId, thread_id: threadId, role: "assistant", content: answer,
    });
    if (replyError) return out({ error: "reply_save_failed" }, 500);
    return out({ answer, thread_id: threadId, is_owner: isOwner });
  } catch (error) {
    console.error("artx-ai-support", error);
    return out({ error: "internal_error" }, 500);
  }
});
