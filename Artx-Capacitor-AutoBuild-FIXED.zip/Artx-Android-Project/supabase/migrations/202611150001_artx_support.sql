-- Idempotent support-history setup. Existing Artx application tables are preserved.
create table if not exists public.artx_support_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) between 1 and 4000),
  created_at timestamptz not null default now()
);

alter table public.artx_support_messages add column if not exists thread_id uuid;
create index if not exists artx_support_messages_user_created_idx
  on public.artx_support_messages (user_id, created_at desc);
create index if not exists artx_support_messages_thread_idx
  on public.artx_support_messages (user_id, thread_id, created_at asc);

alter table public.artx_support_messages enable row level security;
drop policy if exists "Users can read their own Artx support messages" on public.artx_support_messages;
create policy "Users can read their own Artx support messages"
  on public.artx_support_messages for select to authenticated
  using ((select auth.uid()) = user_id);
drop policy if exists "Users can add their own Artx support messages" on public.artx_support_messages;
create policy "Users can add their own Artx support messages"
  on public.artx_support_messages for insert to authenticated
  with check ((select auth.uid()) = user_id and role = 'user');
grant select, insert on public.artx_support_messages to authenticated;
